OUR MEMORIES - CEP 1/3

Upload the contents of this folder to your GitHub repository.

1) index.html is the website.
2) Put your legally usable MP3 song in assets/ and name it music.mp3.
3) If the index.html audio source currently says src="music.mp3", change it to src="assets/music.mp3" for this folder structure.
4) Photos/stickers currently included in index.html may be embedded directly.
5) In GitHub Pages, publish from main branch / root.

Note: this package does not include a music track. Add your own MP3.
